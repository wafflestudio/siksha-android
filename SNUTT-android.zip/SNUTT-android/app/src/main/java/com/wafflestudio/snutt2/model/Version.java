package com.wafflestudio.snutt2.model;

/**
 * Created by makesource on 2017. 2. 20..
 */

public class Version {
    private String version;

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
