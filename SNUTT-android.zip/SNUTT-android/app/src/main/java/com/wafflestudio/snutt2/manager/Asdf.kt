package com.wafflestudio.snutt2.manager

class Asdf {
}