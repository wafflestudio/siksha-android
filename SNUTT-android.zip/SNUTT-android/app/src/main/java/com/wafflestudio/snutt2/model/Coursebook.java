package com.wafflestudio.snutt2.model;

/**
 * Created by makesource on 2017. 3. 7..
 */

public class Coursebook {
    private int semester;
    private int year;

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
