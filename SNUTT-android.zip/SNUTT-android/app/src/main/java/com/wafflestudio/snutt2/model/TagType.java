package com.wafflestudio.snutt2.model;

/**
 * Created by makesource on 2017. 8. 26..
 */

public enum TagType {
    ACADEMIC_YEAR,
    CLASSIFICATION,
    CREDIT,
    DEPARTMENT,
    INSTRUCTOR,
    CATEGORY
}