package com.wafflestudio.snutt2.model;

/**
 * Created by makesource on 2016. 8. 14..
 */
public class Token {
    private String user_id;
    private String token;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
